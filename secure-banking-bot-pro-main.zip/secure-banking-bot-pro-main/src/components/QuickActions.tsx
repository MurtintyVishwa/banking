
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Send, 
  Download, 
  CreditCard, 
  PiggyBank, 
  FileText, 
  Phone,
  ArrowLeftRight,
  Plus
} from "lucide-react";

const QuickActions = () => {
  const actions = [
    {
      icon: Send,
      title: "Send Money",
      description: "Transfer to friends",
      color: "bg-blue-50 hover:bg-blue-100 text-blue-600"
    },
    {
      icon: Download,
      title: "Deposit Check",
      description: "Mobile deposit",
      color: "bg-green-50 hover:bg-green-100 text-green-600"
    },
    {
      icon: CreditCard,
      title: "Pay Bills",
      description: "Manage payments",
      color: "bg-purple-50 hover:bg-purple-100 text-purple-600"
    },
    {
      icon: ArrowLeftRight,
      title: "Transfer",
      description: "Between accounts",
      color: "bg-orange-50 hover:bg-orange-100 text-orange-600"
    },
    {
      icon: PiggyBank,
      title: "Save Money",
      description: "Set savings goals",
      color: "bg-pink-50 hover:bg-pink-100 text-pink-600"
    },
    {
      icon: FileText,
      title: "Statements",
      description: "View & download",
      color: "bg-indigo-50 hover:bg-indigo-100 text-indigo-600"
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="ghost"
              className={`h-auto p-4 flex flex-col items-center space-y-2 ${action.color}`}
            >
              <action.icon className="h-6 w-6" />
              <div className="text-center">
                <p className="font-medium text-sm">{action.title}</p>
                <p className="text-xs opacity-75">{action.description}</p>
              </div>
            </Button>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-slate-800">Need Help?</h4>
              <p className="text-sm text-slate-600">Contact our 24/7 support</p>
            </div>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
              <Phone className="h-4 w-4 mr-2" />
              Call Now
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;
