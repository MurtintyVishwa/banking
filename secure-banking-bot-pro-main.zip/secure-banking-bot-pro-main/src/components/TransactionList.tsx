
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  MoreHorizontal,
  Coffee,
  Car,
  ShoppingCart,
  Home,
  Utensils,
  Wifi
} from "lucide-react";

const TransactionList = () => {
  const transactions = [
    {
      id: 1,
      description: "Coffee Shop on Main St",
      amount: -45.23,
      date: "Today, 10:30 AM",
      category: "Food & Dining",
      icon: Coffee,
      status: "completed"
    },
    {
      id: 2,
      description: "Salary Deposit",
      amount: 3500.00,
      date: "Yesterday, 9:00 AM",
      category: "Income",
      icon: ArrowDownLeft,
      status: "completed"
    },
    {
      id: 3,
      description: "Gas Station",
      amount: -67.89,
      date: "Yesterday, 6:45 PM",
      category: "Transportation",
      icon: Car,
      status: "completed"
    },
    {
      id: 4,
      description: "Online Shopping",
      amount: -123.45,
      date: "2 days ago",
      category: "Shopping",
      icon: ShoppingCart,
      status: "pending"
    },
    {
      id: 5,
      description: "Rent Payment",
      amount: -1200.00,
      date: "3 days ago",
      category: "Housing",
      icon: Home,
      status: "completed"
    },
    {
      id: 6,
      description: "Restaurant",
      amount: -89.32,
      date: "3 days ago",
      category: "Food & Dining",
      icon: Utensils,
      status: "completed"
    },
    {
      id: 7,
      description: "Internet Bill",
      amount: -79.99,
      date: "4 days ago",
      category: "Utilities",
      icon: Wifi,
      status: "completed"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-700";
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Recent Transactions</CardTitle>
          <Button variant="outline" size="sm">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center space-x-4">
                <div className={`p-2 rounded-full ${
                  transaction.amount > 0 
                    ? 'bg-green-100 text-green-600' 
                    : 'bg-slate-100 text-slate-600'
                }`}>
                  <transaction.icon className="h-4 w-4" />
                </div>
                <div>
                  <p className="font-medium text-sm">{transaction.description}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <p className="text-xs text-slate-500">{transaction.date}</p>
                    <Badge 
                      variant="secondary" 
                      className={`text-xs ${getStatusColor(transaction.status)}`}
                    >
                      {transaction.status}
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-right">
                  <p className={`font-semibold text-sm ${
                    transaction.amount > 0 ? 'text-green-600' : 'text-slate-800'
                  }`}>
                    {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toFixed(2)}
                  </p>
                  <p className="text-xs text-slate-500">{transaction.category}</p>
                </div>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                  <MoreHorizontal className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TransactionList;
