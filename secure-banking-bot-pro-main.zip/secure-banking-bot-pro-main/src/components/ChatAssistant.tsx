
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  MessageCircle, 
  Send, 
  X, 
  Bot, 
  User,
  Lightbulb,
  CreditCard,
  PieChart,
  Shield
} from "lucide-react";

interface ChatAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: number;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

const ChatAssistant = ({ isOpen, onClose }: ChatAssistantProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hello! I'm your AI banking assistant. I can help you with account information, transactions, financial advice, and more. How can I assist you today?",
      sender: "bot",
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const quickActions = [
    { icon: CreditCard, text: "Check balance", color: "bg-blue-100 text-blue-600" },
    { icon: PieChart, text: "Spending summary", color: "bg-green-100 text-green-600" },
    { icon: Shield, text: "Security settings", color: "bg-purple-100 text-purple-600" },
    { icon: Lightbulb, text: "Financial tips", color: "bg-orange-100 text-orange-600" }
  ];

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: inputMessage,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const botResponse = generateBotResponse(inputMessage);
      const botMessage: Message = {
        id: messages.length + 2,
        text: botResponse,
        sender: "bot",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const generateBotResponse = (userInput: string): string => {
    const input = userInput.toLowerCase();
    
    if (input.includes("balance") || input.includes("account")) {
      return "Your checking account balance is $12,543.67 and your savings account has $25,890.34. Would you like to see more details about any specific account?";
    } else if (input.includes("transaction") || input.includes("payment")) {
      return "I can see your recent transactions. Your last transaction was a $45.23 payment to Coffee Shop on Main St. Would you like to see more transaction history?";
    } else if (input.includes("transfer") || input.includes("send")) {
      return "I can help you set up a transfer. To get started, please specify the amount and which accounts you'd like to transfer between. For security, you'll need to complete authentication.";
    } else if (input.includes("budget") || input.includes("spending")) {
      return "Based on your spending patterns, you've spent $3,247 this month. Your top categories are: Groceries ($845), Restaurants ($432), and Gas ($298). Would you like personalized budget recommendations?";
    } else if (input.includes("help") || input.includes("support")) {
      return "I'm here to help! I can assist with account balances, transaction history, transfers, budgeting advice, security settings, and general banking questions. What would you like to know?";
    } else if (input.includes("security") || input.includes("safe")) {
      return "Your account security is our priority. I can help you review recent login activity, update security settings, or enable additional protection features like two-factor authentication.";
    } else {
      return "I understand you're asking about banking services. I can help with account information, transactions, transfers, budgeting, and security. Could you please be more specific about what you'd like assistance with?";
    }
  };

  const handleQuickAction = (actionText: string) => {
    setInputMessage(actionText);
    handleSendMessage();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl h-[600px] flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
          <CardTitle className="flex items-center space-x-2">
            <Bot className="h-6 w-6" />
            <span>AI Banking Assistant</span>
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="h-5 w-5" />
          </Button>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0">
          {/* Quick Actions */}
          <div className="p-4 border-b bg-slate-50">
            <p className="text-sm text-slate-600 mb-3">Quick actions:</p>
            <div className="grid grid-cols-2 gap-2">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  size="sm"
                  onClick={() => handleQuickAction(action.text)}
                  className="justify-start h-auto p-2"
                >
                  <action.icon className={`h-4 w-4 mr-2 ${action.color.split(' ')[1]}`} />
                  <span className="text-xs">{action.text}</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
              >
                <div className={`max-w-[80%] ${message.sender === "user" ? "order-2" : "order-1"}`}>
                  <div className="flex items-start space-x-2">
                    {message.sender === "bot" && (
                      <div className="bg-purple-100 p-2 rounded-full">
                        <Bot className="h-4 w-4 text-purple-600" />
                      </div>
                    )}
                    <div
                      className={`p-3 rounded-lg ${
                        message.sender === "user"
                          ? "bg-blue-600 text-white"
                          : "bg-slate-100 text-slate-800"
                      }`}
                    >
                      <p className="text-sm">{message.text}</p>
                      <p
                        className={`text-xs mt-1 ${
                          message.sender === "user" ? "text-blue-100" : "text-slate-500"
                        }`}
                      >
                        {message.timestamp.toLocaleTimeString([], {
                          hour: "2-digit",
                          minute: "2-digit"
                        })}
                      </p>
                    </div>
                    {message.sender === "user" && (
                      <div className="bg-blue-100 p-2 rounded-full">
                        <User className="h-4 w-4 text-blue-600" />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="max-w-[80%]">
                  <div className="flex items-start space-x-2">
                    <div className="bg-purple-100 p-2 rounded-full">
                      <Bot className="h-4 w-4 text-purple-600" />
                    </div>
                    <div className="p-3 rounded-lg bg-slate-100">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
                        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div className="p-4 border-t bg-white">
            <div className="flex space-x-2">
              <Input
                placeholder="Type your message..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage} className="bg-purple-600 hover:bg-purple-700">
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatAssistant;
