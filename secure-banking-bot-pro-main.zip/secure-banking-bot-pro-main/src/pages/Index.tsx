
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  CreditCard, 
  DollarSign, 
  TrendingUp, 
  MessageCircle, 
  Send, 
  Eye, 
  EyeOff,
  ArrowUpRight,
  ArrowDownLeft,
  Shield,
  Bell,
  Settings,
  User
} from "lucide-react";
import ChatAssistant from "@/components/ChatAssistant";
import TransactionList from "@/components/TransactionList";
import QuickActions from "@/components/QuickActions";

const Index = () => {
  const [showBalance, setShowBalance] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(false);

  const accounts = [
    {
      id: 1,
      name: "Checking Account",
      balance: 12543.67,
      accountNumber: "****2341",
      type: "checking"
    },
    {
      id: 2,
      name: "Savings Account",
      balance: 25890.34,
      accountNumber: "****5678",
      type: "savings"
    },
    {
      id: 3,
      name: "Credit Card",
      balance: -1205.45,
      accountNumber: "****9012",
      type: "credit"
    }
  ];

  const totalBalance = accounts
    .filter(acc => acc.type !== "credit")
    .reduce((sum, acc) => sum + acc.balance, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-slate-800">SecureBank Pro</h1>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <Bell className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-slate-800 mb-2">
            Welcome back, John
          </h2>
          <p className="text-slate-600">Here's your financial overview for today</p>
        </div>

        {/* Account Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Balance Card */}
          <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-blue-100">
                Total Balance
              </CardTitle>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-blue-100 hover:text-white"
                onClick={() => setShowBalance(!showBalance)}
              >
                {showBalance ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              </Button>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {showBalance ? `$${totalBalance.toLocaleString()}` : "••••••"}
              </div>
              <div className="flex items-center text-xs text-blue-100 mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +2.4% from last month
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Monthly Spending</CardTitle>
              <DollarSign className="h-4 w-4 text-slate-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$3,247</div>
              <div className="flex items-center text-xs text-green-600 mt-1">
                <ArrowDownLeft className="h-3 w-3 mr-1" />
                -12% vs last month
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Cards</CardTitle>
              <CreditCard className="h-4 w-4 text-slate-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <div className="text-xs text-slate-600 mt-1">
                2 debit, 1 credit
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Rewards Points</CardTitle>
              <TrendingUp className="h-4 w-4 text-slate-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12,450</div>
              <div className="flex items-center text-xs text-green-600 mt-1">
                <ArrowUpRight className="h-3 w-3 mr-1" />
                +340 this month
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Accounts */}
          <div className="lg:col-span-2 space-y-6">
            {/* Accounts Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Your Accounts
                  <Badge variant="secondary">{accounts.length} accounts</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {accounts.map((account) => (
                  <div key={account.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-slate-50 transition-colors">
                    <div className="flex items-center space-x-4">
                      <div className={`p-2 rounded-full ${
                        account.type === 'checking' ? 'bg-blue-100 text-blue-600' :
                        account.type === 'savings' ? 'bg-green-100 text-green-600' :
                        'bg-orange-100 text-orange-600'
                      }`}>
                        <CreditCard className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-medium">{account.name}</p>
                        <p className="text-sm text-slate-500">{account.accountNumber}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-semibold ${
                        account.balance < 0 ? 'text-red-600' : 'text-slate-800'
                      }`}>
                        {showBalance ? 
                          `${account.balance < 0 ? '-' : ''}$${Math.abs(account.balance).toLocaleString()}` : 
                          "••••••"
                        }
                      </p>
                      <p className="text-xs text-slate-500 capitalize">{account.type}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Transactions */}
            <TransactionList />
          </div>

          {/* Right Column - Quick Actions & AI Assistant */}
          <div className="space-y-6">
            <QuickActions />
            
            {/* AI Assistant Toggle */}
            <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageCircle className="h-5 w-5 text-purple-600" />
                  <span>AI Banking Assistant</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-4">
                  Get instant help with your banking needs, transaction queries, and financial advice.
                </p>
                <Button 
                  onClick={() => setIsChatOpen(true)}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Start Chat
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* AI Chat Assistant */}
      <ChatAssistant isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </div>
  );
};

export default Index;
